%TF.GenerationSoftware,KiCad,Pcbnew,9.0.9*%
%TF.CreationDate,2026-07-25T11:45:01+00:00*%
%TF.ProjectId,watch,77617463-682e-46b6-9963-61645f706362,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.9) date 2026-07-25 11:45:01*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
